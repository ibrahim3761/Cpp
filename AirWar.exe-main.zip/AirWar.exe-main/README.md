# AirWar.exe
AirWar.exe is a simple battle game made using the **QT Framework and C++.** <br />
Download the release file and run the executable. <br />
Watch the Demo Here : https://www.youtube.com/watch?v=KU4zy4y-0Og <br />

![image](https://user-images.githubusercontent.com/59500722/209434287-8cc96ff3-2ce6-49b0-b4a0-b06a049e3e95.png)
